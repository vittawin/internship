// const { json } = require("express");

// const { redirect } = require("express/lib/response");

async function checkUser(username, password) {
    const data = {
        type: "login",
        username: username,
        password: password
    };
    const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    const response = await fetch("/database", options);
    const json = await response.json();
    let userdata=json.userdata
    console.log(json);
    if (json.status == 'password matched') {
        alert('เข้าสู่ระบบสำเร็จ กรุณากดปุ่มเพื่อไปหน้าถัดไป');        
        document.cookie = "username="+username;
        document.cookie = "password="+password;
        document.cookie = "firstName="+userdata.firstName;
        document.cookie = "lastName="+userdata.lastName;

        console.log(document.cookie)
        document.getElementById("next").style.display = "block"
    }
    else if (json.status == 'password not matched'){
        alert('รหัสผ่านไม่ถูกต้อง');    
    }
    else if (json.status == 'user not found'){
        alert('ชื่อผู้ใช้งานไม่ถูกต้อง');    
    }
}

function Addvalue(){
    const username = document.querySelector("#username").value
    const password = document.querySelector('#password').value
    console.log(username)
    checkUser(username,password)
    
}
let cookies = document.cookie
        .split(';')
        .map(cookie => cookie.split('='))
        .reduce((accumulator, [key, value]) => ({ ...accumulator, [key.trim()]: decodeURIComponent(value) }), {});
    let curuser = cookies.username;
    let curfname = cookies.firstName;
    let curlname = cookies.lastName;
document.getElementById('show_user').innerHTML = "username = "+curuser


