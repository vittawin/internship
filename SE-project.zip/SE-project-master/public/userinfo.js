let cookies = document.cookie
        .split(';')
        .map(cookie => cookie.split('='))
        .reduce((accumulator, [key, value]) => ({ ...accumulator, [key.trim()]: decodeURIComponent(value) }), {});
// ดึงมาจากคุกกี้
let curuser = cookies.username;
let curfname = cookies.firstName;
let curlname = cookies.lastName;
// แสดงผล
document.getElementById('username').innerHTML = "username : "+curuser
document.getElementById('f_name').innerHTML = "firstName : "+curfname
document.getElementById('l_name').innerHTML = "lastName : "+curlname
