function logout(){
    console.log('logout แล้วนะไอสั๊ส')
    document.cookie = "username="+'';
    document.cookie = "password="+'';
    document.cookie = "firstName="+'';
    document.cookie = "lastName="+'';
}