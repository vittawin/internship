async function updatePassword(newpass) {
    // อ่าน cookie
    let cookies = document.cookie
        .split(';')
        .map(cookie => cookie.split('='))
        .reduce((accumulator, [key, value]) => ({ ...accumulator, [key.trim()]: decodeURIComponent(value) }), {});
    let curpassword = cookies.password;
    
    console.log(curpassword);
    console.log(newpass);      
    const data = {
        type: "update password",
        newpassword : newpass,
        curpassword : curpassword,
        username : cookies.username
    };
    const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    const response = await fetch("/database", options);
    const json = await response.json();
    console.log(json);
    if (json.status == "password change") {
        alert('เปลี่ยนรหัสผ่านสำเร็จ');
    }
    
    // console.log(json);  
    

}

// updateUserInfo("mungseeso123", "suekaelaokai456","mungse0071");
function Addvalue(){
    const newpassword = document.querySelector('#password').value
    updatePassword(newpassword)
    
}