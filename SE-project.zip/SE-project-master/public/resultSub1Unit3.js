async function addScore(userscore) {
    // อ่าน cookie
    let cookies = document.cookie
        .split(';')
        .map(cookie => cookie.split('='))
        .reduce((accumulator, [key, value]) => ({ ...accumulator, [key.trim()]: decodeURIComponent(value) }), {});
    let curuser = cookies.username;
    // console.log(curuser);
    ex_id = '1.3'
    const data = {
        type: "update score",
        userscore : userscore,
        ex_id : ex_id,
        curuser : curuser    
    };
    const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    const response = await fetch("/database", options);
    const json = await response.json();
    console.log(json);
     
    // console.log(json);  
    // document.getElementById("userinfo").innerHTML = json.username; //ถ้าเป็นtext box ใช้ .value

}
console.log(userscore)
addScore(userscore);
