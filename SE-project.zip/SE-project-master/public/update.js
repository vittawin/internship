async function updateUserInfo(newfirst, newlast, newuser,) {
    // อ่าน cookie
    let cookies = document.cookie
        .split(';')
        .map(cookie => cookie.split('='))
        .reduce((accumulator, [key, value]) => ({ ...accumulator, [key.trim()]: decodeURIComponent(value) }), {});
    let curuser = cookies.username;
    // console.log(curuser);
    let curfirst = cookies.firstName;
    let curlast = cookies.lastName;
    const data = {
        type: "update info",
        newfirst: newfirst,
        newlast: newlast ,
        newuser : newuser,
        curuser : curuser,
        curfirst : curfirst,
        curlast : curlast
    };
    const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    const response = await fetch("/database", options);
    const json = await response.json();
    console.log(json);
    if (json.status == "user already existed") {
        alert('มีชื่อผู้ใช้นี้ในระบบแล้ว');
    }
    else if(json.status == 'user change'){ //จำชื่อใหม่
        alert('เปลี่ยนสำเร็จ')
        document.cookie = "username=" + newuser;
    } 
    // console.log(json);  
    document.getElementById("userinfo").innerHTML = json.username; //ถ้าเป็นtext box ใช้ .value

}

// updateUserInfo("mungseeso123", "suekaelaokai456","mungse0071");
function Addvalue(){
    const firstName = document.querySelector("#firstname").value
    const lastName = document.querySelector('#lastname').value
    const username = document.querySelector('#username').value
    updateUserInfo(firstName,lastName,username)
    
}