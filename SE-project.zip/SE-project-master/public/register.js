async function addNewUser(f_name, l_name, username, password) {
    
    const data = {
        type: "register",
        firstName: f_name,
        lastName: l_name,
        username: username,
        password: password
    };
    const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    
    const response = await fetch("/database", options);
    const json = await response.json();
    console.log(json);
    if (json.status == 'user already existed') {
        alert('มีชื่อผู้ใช้อยู่ในระบบแล้ว');
    }
    else if (json.status == 'user created') {
        alert('สมัครสมาชิกสำเร็จ');
    }
}

// addNewUser("mungseeso123", "suekaelaokai456","mungse0071","123456");

async function Addvalue(){
    const f_name = document.querySelector("#firstname").value
    const l_name = document.querySelector('#lastname').value
    const username = document.querySelector("#username").value
    const password = document.querySelector('#password').value
    console.log(username)
    await addNewUser(f_name,l_name,username,password);
    
}

