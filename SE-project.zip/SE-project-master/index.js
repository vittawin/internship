const express = require("express"); 
const app = express();
app.listen(3000, () => console.log("Listening at port 3000"));
app.use(express.static("public"));
app.use(express.json({limit : "1MB"}));

// Setup post
app.post("/database", async (request, response) => {
    console.log("Request received");
    const data = request.body;
    console.log(data);
    await connectToDatabase(data, response);
});

const {MongoClient} = require('mongodb');
async function connectToDatabase(data, response) {
    const uri = "mongodb+srv://seproject:seproject@cluster0.wyrob.mongodb.net/test";
    const client = new MongoClient(uri);
    var type = data.type;
    try {
        console.log("Connecting to the database...");
        await client.connect();
        console.log("Connected to the database.");
        if (type == 'register') {
            let result = await findOneUserByUserName(client, data.username);
            if (result) {
                response.json({
                    status : "user already existed"
                });
            }
            else {
                await createUser(client, {
                    firstName: data.firstName,
                    lastName: data.lastName,
                    username: data.username,
                    password: data.password
                });
                response.json({
                    status : "user created"
                });
            }
            
        }
        else if (type == 'login') {
            let result = await findOneUserByUserName(client, data.username);
            if (!result) {
                response.json({
                    status : "user not found"
                });
            }
            else if (result.password != data.password) {
                response.json({
                    status : "password not matched"
                });
            }
            else {
                response.json({
                    status : "password matched",
                    userdata : result
                });
            }    
        }
        else if (type == 'update info') {           
            console.log(data);
            let result = await findOneUserByUserName(client, data.newuser);
            if (result) {
                response.json({
                    status : "user already existed"
                });
            }
            else {
                let f_res = await updateFirstName(client, data.curfirst, data.newfirst, data.curuser);
                let l_res = await updateLastName(client, data.curlast, data.newlast, data.curuser);
                let u_res = await updateUserName(client, data.curuser, data.newuser);
                
                response.json({
                    status : "user change"
                });     
            }           
        }
        else if (type == 'update password'){
            let p_res = await updatePassword(client,data.curpassword,data.newpassword, data.username);
            response.json({status : 'password change'})
        }
        // List databases
        // await listDatabases(client);
        else if(type == "update score"){
            //เจอusernameแล้วไม่มีex_id หรือไม่เจอuser
            let a = await findOneUserByUserNamescoreid(client,data.curuser,data.ex_id)
            console.log(a)
            if(!a) {
                console.log('sdffsdfdfdf')
                await createUserscore(client, {
                    username : data.curuser,
                    exId : data.ex_id,
                    userscore : data.userscore
                });
                
            }
            else{
                console.log('else')
                await updateUserscore(client,data.curuser,data.ex_id,data.userscore)

            }
         
        } 
        else if(type == 'show score'){
            let a = await findOneUserByUserNameExid(client,data.curuser,data.exid)
            response.json({
                status : 'do white',
                info : a
            });
        }            
    }
    catch (e) {
        console.error(e);
    }
    finally {
        // Close the connection to the MongoDB cluster
        await client.close();
    }
}
 
// main().catch(console.error);
 
// List databases from MongoDB
async function listDatabases(client) {
    databasesList = await client.db().admin().listDatabases();
    console.log("Databases:");
    databasesList.databases.forEach(db => console.log(` - ${db.name}`));
}

// https://www.mongodb.com/developer/quickstart/node-crud-tutorial/



//Function jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa

// Create an user info
async function createUser(client, newUser){
    const result = await client.db("Database").collection("UserInfo").insertOne(newUser);
    console.log(`New user created with the following id: ${result.insertedId}`);
}

//login เรียกมาเทียบ
async function findOneUserByUserName(client, nameOfUserName) {
    // See https://mongodb.github.io/node-mongodb-native/3.6/api/Collection.html#findOne for the findOne() docs
    const result = await client.db("Database").collection("UserInfo").findOne({ username: nameOfUserName });

    if (result) {
        console.log(`Found an user in the collection with the name '${nameOfUserName}':`);
        // console.log(result);
    } else {
        console.log(`No users found with the name '${nameOfUserName}'`);
    }
    return result;
}

async function findOneUserByUserNameExid(client, nameOfUserName,ex_id) {
    // See https://mongodb.github.io/node-mongodb-native/3.6/api/Collection.html#findOne for the findOne() docs
    const result = await client.db("Database").collection("Userscore").findOne({ username: nameOfUserName ,exId : ex_id});

    if (result) {
        console.log(`Found an user in the collection with the name '${nameOfUserName}':`);
        // console.log(result);
    } else {
        console.log(`No users found with the name '${nameOfUserName}'`);
    }
    return result;
}

//อัพเดททีละตัว

async function updateUserName(client, oldUserName, newUserName) {
    // See https://mongodb.github.io/node-mongodb-native/3.6/api/Collection.html#updateOne for the updateOne() docs
    const result = await client.db("Database").collection("UserInfo").updateOne({ username: oldUserName }, { $set: {username: newUserName}});
    // console.log(`${result.matchedCount} document(s) matched the query criteria.`);
    // console.log(`${result.modifiedCount} document(s) was/were updated.`);
    return result;
}

async function updatePassword(client, oldPassword, newPassword, username) {
    // See https://mongodb.github.io/node-mongodb-native/3.6/api/Collection.html#updateOne for the updateOne() docs
    // const userresult = await findOneUserByUserName(client, username);
    const result = await client.db("Database").collection("UserInfo").updateOne({ username: username, password: oldPassword }, { $set: {password: newPassword} });
    // console.log(`${result.matchedCount} document(s) matched the query criteria.`);
    // console.log(`${result.modifiedCount} document(s) was/were updated.`);
    return result;
}

async function updateFirstName(client, oldFirstName, newFirstName, username) {
    console.log("update fname")
    // See https://mongodb.github.io/node-mongodb-native/3.6/api/Collection.html#updateOne for the updateOne() docs
    // const userresult = await findOneUserByUserName(client, username);
    const result = await client.db("Database").collection("UserInfo").updateOne({ username: username, firstName: oldFirstName }, { $set: {firstName: newFirstName} });
    console.log(`${result.matchedCount} document(s) matched the query criteria.`);
    console.log(`${result.modifiedCount} document(s) was/were updated.`);
    
    return result;
}

async function updateLastName(client, oldLastName, newLastName, username) {
    console.log("update fname")
    // See https://mongodb.github.io/node-mongodb-native/3.6/api/Collection.html#updateOne for the updateOne() docs
    // const userresult = await findOneUserByUserName(client, username);
    const result = await client.db("Database").collection("UserInfo").updateOne({ username: username, lastName: oldLastName }, { $set: {lastName: newLastName} });
    console.log(`${result.matchedCount} document(s) matched the query criteria.`);
    console.log(`${result.modifiedCount} document(s) was/were updated.`);
    
    return result;
}

async function createUserscore(client, newUserscore){
    const result = await client.db("Database").collection("Userscore").insertOne(newUserscore);
    console.log(`New user score created with the following id: ${result.insertedId}`);
}

async function updateUserscore(client,curuser,exId,userscore){
    const result = await client.db("Database").collection("Userscore").updateOne({ username: curuser, exId: exId }, { $set: {userscore: userscore} });
    console.log(`${result.matchedCount} document(s) matched the query criteria.`);
    console.log(`${result.modifiedCount} document(s) was/were updated.`);
}

async function findOneUserByUserNamescoreid(client, nameOfUserName,exId) {
    // See https://mongodb.github.io/node-mongodb-native/3.6/api/Collection.html#findOne for the findOne() docs
    const result = await client.db("Database").collection("Userscore").findOne({ username: nameOfUserName ,exId: exId});

    if (result) {
        console.log(`Found an user in the collection with the name '${nameOfUserName}':`);
        // console.log(result);
    } else {
        console.log(`No users found with the name '${nameOfUserName}'`);
    }
    return result;
}



